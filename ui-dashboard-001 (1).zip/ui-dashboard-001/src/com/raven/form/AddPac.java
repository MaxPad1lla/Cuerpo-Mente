package com.raven.form;

import com.raven.form.PacienteDAO;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Window;

public class AddPac extends javax.swing.JPanel {

    private Form_1 form1;
    public AddPac(Form_1 form1) {
        this.form1 = form1;
        initComponents();
    }
    public AddPac() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        TfName = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        TfApellido = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        TfTelefono = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        btnConfirmar = new javax.swing.JButton();

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        jLabel1.setText("Añadir nuevo cliente");
        bg.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel2.setText("Nombre:");
        bg.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 100, -1, -1));

        TfName.setBorder(null);
        TfName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfNameActionPerformed(evt);
            }
        });
        bg.add(TfName, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 200, -1));
        bg.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 140, 210, 10));

        TfApellido.setBorder(null);
        TfApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfApellidoActionPerformed(evt);
            }
        });
        bg.add(TfApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, 200, -1));
        bg.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 210, 10));

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel3.setText("Apellido:");
        bg.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, -1, -1));

        TfTelefono.setBorder(null);
        TfTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfTelefonoActionPerformed(evt);
            }
        });
        bg.add(TfTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 240, 200, -1));
        bg.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 260, 210, 10));

        jLabel4.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel4.setText("Teléfono:");
        bg.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, -1, -1));

        btnConfirmar.setBackground(new java.awt.Color(204, 255, 204));
        btnConfirmar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnConfirmar.setText("Confirmar");
        btnConfirmar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 255, 102), new java.awt.Color(204, 255, 204), null, null));
        btnConfirmar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnConfirmarMouseClicked(evt);
            }
        });
        bg.add(btnConfirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 290, 100, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void TfNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfNameActionPerformed

    private void TfApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfApellidoActionPerformed

    private void TfTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfTelefonoActionPerformed

    private void btnConfirmarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConfirmarMouseClicked
  String nombre = TfName.getText().trim();
    String apellido = TfApellido.getText().trim();
    String telefono = TfTelefono.getText().trim();

    if (nombre.isEmpty() || apellido.isEmpty() || telefono.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
        return;
    }

    PacienteDAO dao = new PacienteDAO();
    boolean exito = dao.insertPaciente(nombre, apellido, telefono);

    if (exito) {
        JOptionPane.showMessageDialog(this, "Paciente agregado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        // Refrescar tabla en Form_1
        form1.refrescarTablaPacientes();

        // Cerrar ventana
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window != null) {
            window.dispose();
        }
    } else {
        JOptionPane.showMessageDialog(this, "No se pudo guardar el paciente.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnConfirmarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TfApellido;
    private javax.swing.JTextField TfName;
    private javax.swing.JTextField TfTelefono;
    private javax.swing.JPanel bg;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    // End of variables declaration//GEN-END:variables
}

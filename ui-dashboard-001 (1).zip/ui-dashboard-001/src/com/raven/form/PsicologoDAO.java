package com.raven.form;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PsicologoDAO {
public boolean insertPsicologo(String nombre, String apellido, String telefono, String cepro, String especialidad) {
    String sql = """
        INSERT INTO psicologo (nombre_psi, apellido_psi, tel_psi, cepro_psi, esp_psi)
        VALUES (?, ?, ?, ?, ?)
        """;

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, nombre);
        pstmt.setString(2, apellido);
        pstmt.setString(3, telefono);
        pstmt.setString(4, cepro);
        pstmt.setString(5, especialidad);

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
}
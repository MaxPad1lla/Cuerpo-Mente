package com.raven.form;

import com.raven.form.CitaDAO;
import com.raven.model.StatusType;
import com.raven.form.DatabaseConnection;
import java.awt.Window;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;
import com.raven.model.Model_Card;
import com.raven.model.StatusType;
import com.raven.swing.ScrollBar;
import com.raven.swing.Table;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import com.raven.form.DatabaseConnection;
import java.sql.*;

public class AddCita extends javax.swing.JPanel {
    private Form_4 form4;

    public AddCita(Form_Home formHome, Form_4 form4) {
        this.formHome = formHome;
        this.form4 = form4; 
        initComponents();
    }

    private Form_Home formHome;
    private int id_psi;

    public AddCita(Form_Home formHome) {
        this.formHome = formHome;
        initComponents();
    }

    public AddCita() {
        initComponents();
    }
private int obtenerIdPsicologo(String nombre) {
    String sql = "SELECT id_psi FROM psicologo WHERE nombre_psi = ?";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nombre);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("id_psi");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return -1;
}

private int obtenerIdPaciente(String nombre) {
    String sql = "SELECT id_pac FROM paciente WHERE nombre_pac = ?";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        
        pstmt.setString(1, nombre);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt("id_pac");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return -1;
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnAdd = new javax.swing.JLabel();
        TfHora = new javax.swing.JTextField();
        jScrollBar1 = new javax.swing.JScrollBar();
        jScrollBar2 = new javax.swing.JScrollBar();
        jLabel6 = new javax.swing.JLabel();
        TfEspecialidad = new javax.swing.JTextField();
        jSeparator5 = new javax.swing.JSeparator();
        bg = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        btnConfirmar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        CBsico = new javax.swing.JComboBox<>();
        CBCon = new javax.swing.JComboBox<>();
        CBPac = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        TfFecha = new javax.swing.JTextField();
        CBHoraInicio = new javax.swing.JComboBox<>();

        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/añadir.png"))); // NOI18N
        btnAdd.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAddMouseClicked(evt);
            }
        });

        TfHora.setBorder(null);
        TfHora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfHoraActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel6.setText("Especialidad:");

        TfEspecialidad.setBorder(null);
        TfEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfEspecialidadActionPerformed(evt);
            }
        });

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        jLabel1.setText("Nueva Cita");
        bg.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel2.setText("Psicologo:");
        bg.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));
        bg.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 210, 10));
        bg.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 210, 10));

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel3.setText("Paciente:");
        bg.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, -1, -1));
        bg.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, 100, 10));

        jLabel4.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel4.setText("Consultorio:");
        bg.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, -1));

        btnConfirmar.setBackground(new java.awt.Color(204, 255, 204));
        btnConfirmar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnConfirmar.setText("Confirmar");
        btnConfirmar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 255, 102), new java.awt.Color(204, 255, 204), null, null));
        btnConfirmar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConfirmar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnConfirmarMouseClicked(evt);
            }
        });
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });
        bg.add(btnConfirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 360, 100, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel5.setText("Fecha:");
        bg.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 170, -1, -1));
        bg.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 270, 210, 10));

        CBsico.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        CBsico.setBorder(null);
        CBsico.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        CBsico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CBsicoActionPerformed(evt);
            }
        });
        bg.add(CBsico, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 210, -1));

        CBCon.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        bg.add(CBCon, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 200, 90, -1));

        CBPac.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        bg.add(CBPac, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 210, -1));

        jLabel7.setText("Hora:");
        bg.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 230, -1, -1));
        bg.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 210, 210, 10));

        TfFecha.setBorder(null);
        TfFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfFechaActionPerformed(evt);
            }
        });
        bg.add(TfFecha, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, 200, -1));

        CBHoraInicio.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00" }));
        bg.add(CBHoraInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 250, 210, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 522, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void TfHoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfHoraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfHoraActionPerformed

    private void TfEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfEspecialidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfEspecialidadActionPerformed

    private void CBsicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CBsicoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CBsicoActionPerformed

    private void btnAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddMouseClicked

    }//GEN-LAST:event_btnAddMouseClicked
public void setPsicologos(String[] nombres) {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(nombres);
        CBsico.setModel(model);
    }
 public void setConsultorios(String[] nombres) {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(nombres);
        CBCon.setModel(model);  
    }
public void setPacientes(String[] nombres) {
    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(nombres);
    CBPac.setModel(model); // Asegúrate de que CBPaciente sea el nombre correcto
}
    private void btnConfirmarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConfirmarMouseClicked
     String nombrePsicologo = (String) CBsico.getSelectedItem();
        String nombrePaciente = (String) CBPac.getSelectedItem();
        String consultorioStr = (String) CBCon.getSelectedItem();
        String fechaStr = TfFecha.getText().trim();
        String estado = "PENDIENTE";

        if (nombrePsicologo == null || nombrePaciente == null || consultorioStr == null || fechaStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Parsear fecha
        java.sql.Date fecha;
        try {
            fecha = java.sql.Date.valueOf(fechaStr);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Formato de fecha inválido. Use: YYYY-MM-DD", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int idConsultorio;
        try {
            idConsultorio = Integer.parseInt(consultorioStr);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El consultorio debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int idPsicologo = obtenerIdPsicologo(nombrePsicologo);
        int idPaciente = obtenerIdPaciente(nombrePaciente);

        if (idPsicologo == -1) {
            JOptionPane.showMessageDialog(this, "Psicólogo no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (idPaciente == -1) {
            JOptionPane.showMessageDialog(this, "Paciente no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String horaStr = (String) CBHoraInicio.getSelectedItem();
        java.sql.Time horaInicio;
        try {
            horaInicio = java.sql.Time.valueOf(horaStr + ":00"); 
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Hora inválida.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        long unaHoraEnMs = 60 * 60 * 1000;
        java.sql.Time horaFin = new java.sql.Time(horaInicio.getTime() + unaHoraEnMs);
int idUsu = 18; 
    CitaDAO dao = new CitaDAO();
    boolean exito = dao.insertReserva(
        idPsicologo,
        idPaciente,
        idConsultorio,
        fecha,
        horaInicio,
        horaFin,
        estado,
        idUsu  
    );

    if (exito) {
        JOptionPane.showMessageDialog(this, "Cita agregada con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        if (formHome != null)formHome.refrescarTablaCitas();
        if (form4 != null) form4.refrescarTablaDECitas();

        Window window = SwingUtilities.getWindowAncestor(this);
        if (window != null) window.dispose();
    } else {
        JOptionPane.showMessageDialog(this, "No se pudo guardar la reserva.", "Error", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_btnConfirmarMouseClicked

    private void TfFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfFechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfFechaActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CBCon;
    private javax.swing.JComboBox<String> CBHoraInicio;
    private javax.swing.JComboBox<String> CBPac;
    private javax.swing.JComboBox<String> CBsico;
    private javax.swing.JTextField TfEspecialidad;
    private javax.swing.JTextField TfFecha;
    private javax.swing.JTextField TfHora;
    private javax.swing.JPanel bg;
    private javax.swing.JLabel btnAdd;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JScrollBar jScrollBar2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    // End of variables declaration//GEN-END:variables
}
// CitaDAO.java
package com.raven.form;

import com.raven.form.DatabaseConnection;
import com.raven.form.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.sql.Time;

public class CitaDAO {

    public boolean insertReserva(int idPsi, int idPac, int idCon, Date fecha,
                                 Time horaInicio, Time horaFin, String estado, int idUsu) {
        
        String sql = """
            INSERT INTO reserva 
            (id_psi, id_pac, id_con, fecha_res, hora_inicio, hora_fin, estado, id_usu)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, idPsi);           // id_psi
            pstmt.setInt(2, idPac);           // id_pac
            pstmt.setInt(3, idCon);           // id_con
            pstmt.setDate(4, fecha);          // fecha_res
            pstmt.setTime(5, horaInicio);     // hora_inicio
            pstmt.setTime(6, horaFin);        // hora_fin
            pstmt.setString(7, estado);       // estado
            pstmt.setInt(8, idUsu);           // id_usu

            int filas = pstmt.executeUpdate();
            return filas > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
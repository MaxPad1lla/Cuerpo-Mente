package com.raven.form;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

// Luis Maximiliano Padilla Díaz de León 240794, Melanie Ximena García Palos 240789, José Eduardo Vázquez Mora 240799 //

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/proyectoint2";
    private static final String USER = "root";
    private static final String PASSWORD = "patatana1.";

    public static Connection getConnection() { // ← Nombre exacto
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    static Connection getConexion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
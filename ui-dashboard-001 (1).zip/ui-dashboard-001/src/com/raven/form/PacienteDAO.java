package com.raven.form;

import com.raven.form.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PacienteDAO {
  public boolean insertPaciente(String nombre, String apellido, String telefono) {
    String sql = """
        INSERT INTO paciente (nombre_pac, apellido_pac, tel_pac)
        VALUES (?, ?, ?)
        """;

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, nombre);
        pstmt.setString(2, apellido);
        pstmt.setString(3, telefono);

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
  }
}
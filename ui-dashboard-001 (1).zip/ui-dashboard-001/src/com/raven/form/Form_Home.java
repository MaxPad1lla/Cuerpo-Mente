package com.raven.form;

import com.raven.model.Model_Card;
import com.raven.model.StatusType;
import com.raven.swing.ScrollBar;
import com.raven.swing.Table;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import com.raven.form.DatabaseConnection;
import java.sql.*;

public class Form_Home extends javax.swing.JPanel {

    public Form_Home() {
        initComponents();
        Table table = new Table(true);
        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);
        card1.setData(new Model_Card(
            new ImageIcon(getClass().getResource("/com/raven/icon/psico.png")),
            "Psicólogos", "", ""
        ));
        card2.setData(new Model_Card(
            new ImageIcon(getClass().getResource("/com/raven/icon/cliente.png")),
            "Pacientes", "", ""
        ));
        card3.setData(new Model_Card(
            new ImageIcon(getClass().getResource("/com/raven/icon/usuario.png")),
            "Usuarios", "", ""
        ));
        spTable.setVerticalScrollBar(new ScrollBar());
        spTable.getVerticalScrollBar().setBackground(Color.WHITE);
        spTable.getViewport().setBackground(Color.WHITE);
        JPanel corner = new JPanel();
        corner.setBackground(Color.WHITE);
        spTable.setCorner(JScrollPane.UPPER_RIGHT_CORNER, corner);

        cargarDatosDesdeBD();
    }
public void refrescarTablaCitas() {
    DefaultTableModel model = (DefaultTableModel) table.getModel();
    model.setRowCount(0); // Limpia la tabla

    String sql = """
        SELECT 
            r.id_con AS consultorio,
            p.nombre_psi AS psicologo,
            pa.nombre_pac AS paciente,
            r.fecha_res AS fecha,
            r.hora_inicio AS hora,
            r.estado AS estatus
        FROM reserva r
        JOIN psicologo p ON r.id_psi = p.id_psi
        JOIN paciente pa ON r.id_pac = pa.id_pac
        WHERE r.fecha_res = CURDATE()
        ORDER BY r.hora_inicio
        """;

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         ResultSet rs = pstmt.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("consultorio"),
                rs.getString("psicologo"),
                rs.getString("paciente"),
                rs.getDate("fecha"),
                rs.getTime("hora"),
                rs.getString("estatus")
            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar citas del día: " + e.getMessage());
    }
}
    private void cargarDatosDesdeBD() {
    ((javax.swing.table.DefaultTableModel) table.getModel()).setRowCount(0);
    String fechaHoy = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        System.out.println("Fecha de hoy: " + fechaHoy);
    String sql = "SELECT " +
                 "r.id_con, r.hora_inicio, r.estado, " + 
                 "p.nombre_pac, s.nombre_psi " +
                 "FROM reserva r " +
                 "JOIN paciente p ON r.id_pac = p.id_pac " +
                 "JOIN psicologo s ON r.id_psi = s.id_psi " +
                 "WHERE r.fecha_res = ? " +
                 "ORDER BY r.hora_inicio";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, fechaHoy);

        try (ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                String consultorio = rs.getString("id_con");
                String hora = rs.getTime("hora_inicio").toString();
                String estadoStr = rs.getString("estado");
                String paciente = rs.getString("nombre_pac");
                String psicologo = rs.getString("nombre_psi");

              
                com.raven.model.StatusType estado;
                switch (estadoStr.toLowerCase()) {
                    case "confirmado":
                        estado = com.raven.model.StatusType.CONFIRMADO;
                        break;
                    case "modificado":
                        estado = com.raven.model.StatusType.MODIFICADO;
                        break;
                    case "cancelado":
                        estado = com.raven.model.StatusType.CANCELADO;
                        break;
                    default:
                        estado = com.raven.model.StatusType.PENDIENTE;
                        break;
                }

               
                table.addRow(new Object[]{
                    consultorio,
                    psicologo,
                    paciente,
                    hora,
                    estado
                });
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
        System.err.println("Error al cargar datos: " + e.getMessage());
        table.addRow(new Object[]{
            "Error",
            "No se pudo cargar",
            "Verifique conexión",
            "",
            com.raven.model.StatusType.CANCELADO
        });
    }
    

}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnmod = new javax.swing.JLabel();
        btndel = new javax.swing.JLabel();
        panel = new javax.swing.JLayeredPane();
        card1 = new com.raven.component.Card();
        card2 = new com.raven.component.Card();
        card3 = new com.raven.component.Card();
        panelBorder1 = new com.raven.swing.PanelBorder();
        jLabel1 = new javax.swing.JLabel();
        spTable = new javax.swing.JScrollPane();
        table = new com.raven.swing.Table();
        btnAdd = new javax.swing.JLabel();

        btnmod.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/modificar.png"))); // NOI18N
        btnmod.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnmod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnmodMouseClicked(evt);
            }
        });

        btndel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/eliminar.png"))); // NOI18N
        btndel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btndel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btndelMouseClicked(evt);
            }
        });

        panel.setLayout(new java.awt.GridLayout(1, 0, 10, 0));

        card1.setColor1(new java.awt.Color(142, 142, 250));
        card1.setColor2(new java.awt.Color(123, 123, 245));
        card1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                card1MouseClicked(evt);
            }
        });
        panel.add(card1);

        card2.setColor1(new java.awt.Color(186, 123, 247));
        card2.setColor2(new java.awt.Color(167, 94, 236));
        panel.add(card2);

        card3.setColor1(new java.awt.Color(241, 208, 62));
        card3.setColor2(new java.awt.Color(211, 184, 61));
        panel.add(card3);

        panelBorder1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(127, 127, 127));
        jLabel1.setText("Citas Del Dia");

        spTable.setBorder(null);

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Consultorio", "Psicologo", "Paciente", "Hora", "Estatus"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        spTable.setViewportView(table);

        btnAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/añadir.png"))); // NOI18N
        btnAdd.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnAdd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAddMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelBorder1Layout = new javax.swing.GroupLayout(panelBorder1);
        panelBorder1.setLayout(panelBorder1Layout);
        panelBorder1Layout.setHorizontalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addComponent(spTable, javax.swing.GroupLayout.DEFAULT_SIZE, 849, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnAdd)
                        .addGap(28, 28, 28))))
        );
        panelBorder1Layout.setVerticalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1))
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnAdd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(spTable, javax.swing.GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, 875, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void card1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_card1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_card1MouseClicked

    private void btnAddMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAddMouseClicked
String[] psicologos = obtenerPsicologos();
String[] pacientes = obtenerPacientes();     
String[] consultorios = obtenerConsultorios();

    JDialog dialog = new JDialog(
    (Frame)    SwingUtilities.getWindowAncestor(this),
        "Nueva Cita",
        true
    );

    AddCita addCita = new AddCita(this);
    addCita.setPsicologos(psicologos);
    addCita.setPacientes(pacientes);             
    addCita.setConsultorios(consultorios);

    dialog.add(addCita);
    dialog.pack();
    dialog.setLocationRelativeTo(null);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    dialog.setVisible(true);
}
private String[] obtenerPsicologos() {
    java.util.List<String> listaNombres = new java.util.ArrayList<>();
    java.util.List<Integer> listaIds = new java.util.ArrayList<>();

    try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "SELECT id_psi, nombre_psi FROM psicologo";
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id_psi");
                String nombre = rs.getString("nombre_psi");
                listaIds.add(id);
                listaNombres.add(nombre);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar psicólogos: " + e.getMessage());
    }
    return listaNombres.toArray(new String[0]);
}
private String[] obtenerPacientes() {
    java.util.List<String> lista = new java.util.ArrayList<>();
    try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "SELECT nombre_pac FROM paciente ORDER BY nombre_pac";
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                lista.add(rs.getString("nombre_pac"));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar pacientes: " + e.getMessage());
    }
    return lista.toArray(new String[0]);
}
private String[] obtenerConsultorios() {
    java.util.List<String> lista = new java.util.ArrayList<>();
    try (Connection conn = DatabaseConnection.getConnection()) {
        String sql = "SELECT id_con FROM consultorio ORDER BY id_con";
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                lista.add(String.valueOf(rs.getInt("id_con")));
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar consultorios: " + e.getMessage());
    }
    return lista.toArray(new String[0]);
            
    }//GEN-LAST:event_btnAddMouseClicked

    private void btnmodMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnmodMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnmodMouseClicked

    private void btndelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndelMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btndelMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btnAdd;
    private javax.swing.JLabel btndel;
    private javax.swing.JLabel btnmod;
    private com.raven.component.Card card1;
    private com.raven.component.Card card2;
    private com.raven.component.Card card3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLayeredPane panel;
    private com.raven.swing.PanelBorder panelBorder1;
    private javax.swing.JScrollPane spTable;
    private com.raven.swing.Table table;
    // End of variables declaration//GEN-END:variables
}
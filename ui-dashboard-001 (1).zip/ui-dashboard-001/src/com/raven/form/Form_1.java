package com.raven.form;

import com.raven.form.DatabaseConnection;
import com.raven.swing.ScrollBar;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import interfazlalo.*;

public class Form_1 extends javax.swing.JPanel {

    public Form_1() {
        initComponents();
        cargarPacientes();
        
        spTable.setVerticalScrollBar(new ScrollBar());
        spTable.getVerticalScrollBar().setBackground(Color.WHITE);
        spTable.getViewport().setBackground(Color.WHITE);
        JPanel corner = new JPanel();
        corner.setBackground(Color.WHITE);
        spTable.setCorner(JScrollPane.UPPER_RIGHT_CORNER, corner);
    }
    
    private void cargarPacientes() {
        ((DefaultTableModel) tablaPaciente.getModel()).setRowCount(0);

        String sql = "SELECT id_pac, nombre_pac, apellido_pac, tel_pac FROM paciente";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String id = rs.getString("id_pac");
                String nombre = rs.getString("nombre_pac");
                String apellido = rs.getString("apellido_pac");
                String telefono = rs.getString("tel_pac");

                ((DefaultTableModel) tablaPaciente.getModel()).addRow(
                    new Object[]{id, nombre, apellido, telefono}
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
            ((DefaultTableModel) tablaPaciente.getModel()).addRow(
                new Object[]{"Error", "No disponible", "BD no accesible"}
            );
        }
    }
public void refrescarTablaPacientes() {
        DefaultTableModel model = (DefaultTableModel) tablaPaciente.getModel();
    model.setRowCount(0);

    String sql = "SELECT id_pac, nombre_pac, apellido_pac, tel_pac FROM paciente";

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         ResultSet rs = pstmt.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("id_pac"),
                rs.getString("nombre_pac"),
                rs.getString("apellido_pac"),
                rs.getString("tel_pac")
            });
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al cargar pacientes: " + e.getMessage());
    }
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnadd = new javax.swing.JLabel();
        btnmod = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        panelBorder1 = new com.raven.swing.PanelBorder();
        jLabel1 = new javax.swing.JLabel();
        spTable = new javax.swing.JScrollPane();
        tablaPaciente = new com.raven.swing.Table();
        btnadd1 = new javax.swing.JLabel();
        btnmod1 = new javax.swing.JLabel();
        btndel = new javax.swing.JLabel();

        btnadd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/añadir.png"))); // NOI18N
        btnadd.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        btnmod.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/modificar.png"))); // NOI18N
        btnmod.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnmod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnmodMouseClicked(evt);
            }
        });

        panelBorder1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(127, 127, 127));
        jLabel1.setText("Pacientes");

        tablaPaciente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Nombre", "Apellido", "Numero"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        spTable.setViewportView(tablaPaciente);

        btnadd1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/añadir.png"))); // NOI18N
        btnadd1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnadd1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnadd1MouseClicked(evt);
            }
        });

        btnmod1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/modificar.png"))); // NOI18N
        btnmod1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnmod1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnmod1MouseClicked(evt);
            }
        });

        btndel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/raven/icon/eliminar.png"))); // NOI18N
        btndel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btndel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btndelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout panelBorder1Layout = new javax.swing.GroupLayout(panelBorder1);
        panelBorder1.setLayout(panelBorder1Layout);
        panelBorder1Layout.setHorizontalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addComponent(spTable, javax.swing.GroupLayout.DEFAULT_SIZE, 740, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnadd1)
                        .addGap(18, 18, 18)
                        .addComponent(btnmod1)
                        .addGap(18, 18, 18)
                        .addComponent(btndel)
                        .addGap(75, 75, 75))))
        );
        panelBorder1Layout.setVerticalGroup(
            panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBorder1Layout.createSequentialGroup()
                .addGroup(panelBorder1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1))
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnmod1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelBorder1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btndel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBorder1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnadd1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(spTable, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(113, 113, 113))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(panelBorder1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 766, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 719, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnmodMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnmodMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btnmodMouseClicked

    private void btnmod1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnmod1MouseClicked
       interfazmodificar.ModPaciente delPsicologo = new interfazmodificar.ModPaciente(); 
    delPsicologo.setLocationRelativeTo(null);
    delPsicologo.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    delPsicologo.setVisible(true);
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btnmod1MouseClicked

    private void btndelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btndelMouseClicked

    DelPaciente delPaciente = new DelPaciente(); 
    delPaciente.setLocationRelativeTo(null);
    delPaciente.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    delPaciente.setVisible(true);
    }//GEN-LAST:event_btndelMouseClicked

    private void btnadd1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnadd1MouseClicked
  JDialog dialog = new JDialog(
     (Frame) SwingUtilities.getWindowAncestor(this),
        "Nuevo Paciente",
        true
    );
    AddPac addPac = new AddPac(this); 
    dialog.add(addPac);
    dialog.pack();
    dialog.setLocationRelativeTo(null);
    dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    dialog.setVisible(true);
    }//GEN-LAST:event_btnadd1MouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btnadd;
    private javax.swing.JLabel btnadd1;
    private javax.swing.JLabel btndel;
    private javax.swing.JLabel btnmod;
    private javax.swing.JLabel btnmod1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private com.raven.swing.PanelBorder panelBorder1;
    private javax.swing.JScrollPane spTable;
    private com.raven.swing.Table tablaPaciente;
    // End of variables declaration//GEN-END:variables

    void refrescarTablaPaciente() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

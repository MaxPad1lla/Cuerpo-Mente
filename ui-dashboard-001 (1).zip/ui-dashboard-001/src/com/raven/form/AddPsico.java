package com.raven.form;

import java.awt.Window;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

public class AddPsico extends javax.swing.JPanel {

    private Form_2 form2;
    public AddPsico() {
        initComponents();
    }
    public AddPsico(Form_2 form2) {
        this.form2 = form2;
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        bg = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        TfName = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        TfApellido = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        TfTelefono = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        btnConfirmar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        TfCedProf = new javax.swing.JTextField();
        jSeparator4 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        TfEspecialidad = new javax.swing.JTextField();
        jSeparator5 = new javax.swing.JSeparator();

        bg.setBackground(new java.awt.Color(255, 255, 255));
        bg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 1, 24)); // NOI18N
        jLabel1.setText("Añadir nuevo psicologo");
        bg.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel2.setText("Nombre:");
        bg.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 100, -1, -1));

        TfName.setBorder(null);
        TfName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfNameActionPerformed(evt);
            }
        });
        bg.add(TfName, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 200, -1));
        bg.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 140, 210, 10));

        TfApellido.setBorder(null);
        TfApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfApellidoActionPerformed(evt);
            }
        });
        bg.add(TfApellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 200, -1));
        bg.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 140, 210, 10));

        jLabel3.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel3.setText("Apellido:");
        bg.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, -1, -1));

        TfTelefono.setBorder(null);
        TfTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfTelefonoActionPerformed(evt);
            }
        });
        bg.add(TfTelefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, 200, -1));
        bg.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, 210, 10));

        jLabel4.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel4.setText("Teléfono:");
        bg.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 170, -1, -1));

        btnConfirmar.setBackground(new java.awt.Color(204, 255, 204));
        btnConfirmar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnConfirmar.setText("Confirmar");
        btnConfirmar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(102, 255, 102), new java.awt.Color(204, 255, 204), null, null));
        btnConfirmar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnConfirmar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnConfirmarMouseClicked(evt);
            }
        });
        btnConfirmar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmarActionPerformed(evt);
            }
        });
        bg.add(btnConfirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 330, 100, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel5.setText("Cedula Profesional:");
        bg.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 170, -1, -1));

        TfCedProf.setBorder(null);
        TfCedProf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfCedProfActionPerformed(evt);
            }
        });
        bg.add(TfCedProf, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, 200, -1));
        bg.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 210, 210, 10));

        jLabel6.setFont(new java.awt.Font("Segoe UI Emoji", 0, 14)); // NOI18N
        jLabel6.setText("Especialidad:");
        bg.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 240, -1, -1));

        TfEspecialidad.setBorder(null);
        TfEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfEspecialidadActionPerformed(evt);
            }
        });
        bg.add(TfEspecialidad, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 260, 350, -1));
        bg.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, 350, 10));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 417, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void TfNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfNameActionPerformed

    }//GEN-LAST:event_TfNameActionPerformed

    private void TfApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfApellidoActionPerformed

    }//GEN-LAST:event_TfApellidoActionPerformed

    private void TfTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfTelefonoActionPerformed

    private void TfCedProfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfCedProfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfCedProfActionPerformed

    private void TfEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfEspecialidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfEspecialidadActionPerformed

    private void btnConfirmarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnConfirmarActionPerformed

    private void btnConfirmarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnConfirmarMouseClicked
    String nombre = TfName.getText().trim();
    String apellido = TfApellido.getText().trim();
    String telefono = TfTelefono.getText().trim();
    String cepro = TfCedProf.getText().trim();
    String especialidad = TfEspecialidad.getText().trim();

    if (nombre.isEmpty() || apellido.isEmpty() || telefono.isEmpty() || cepro.isEmpty() || especialidad.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.", "Campos vacíos", JOptionPane.WARNING_MESSAGE);
        return;
    }

    PsicologoDAO dao = new PsicologoDAO();
    boolean exito = dao.insertPsicologo(nombre, apellido, telefono, cepro, especialidad);

    if (exito) {
        JOptionPane.showMessageDialog(this, "Psicólogo agregado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        // Refrescar tabla en Form_2
        form2.refrescarTablaPsicologos();

        // Cerrar ventana
        Window window = SwingUtilities.getWindowAncestor(this);
        if (window != null) {
            window.dispose();
        }
    } else {
        JOptionPane.showMessageDialog(this, "No se pudo guardar el psicólogo.", "Error", JOptionPane.ERROR_MESSAGE);
    }

    }//GEN-LAST:event_btnConfirmarMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField TfApellido;
    private javax.swing.JTextField TfCedProf;
    private javax.swing.JTextField TfEspecialidad;
    private javax.swing.JTextField TfName;
    private javax.swing.JTextField TfTelefono;
    private javax.swing.JPanel bg;
    private javax.swing.JButton btnConfirmar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    // End of variables declaration//GEN-END:variables
}

package com.raven.form;

import com.raven.form.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UsuarioDAO {
public boolean insertUsuario(String nombre, String apellido, String email, String contrasena, String rol, String estatus) {
    String sql = """
        INSERT INTO usuario 
        (nombre_usu, apellido_usu, email_usu, contrasena_usu, rol_usu, fecha_registro, estatus)
        VALUES (?, ?, ?, ?, ?, NOW(), ?)
        """;

    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, nombre);
        pstmt.setString(2, apellido);
        pstmt.setString(3, email);
        pstmt.setString(4, contrasena);  // En producción: usa hash (BCrypt)
        pstmt.setString(5, rol);
        pstmt.setString(6, estatus);

        int filas = pstmt.executeUpdate();
        return filas > 0;

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
}
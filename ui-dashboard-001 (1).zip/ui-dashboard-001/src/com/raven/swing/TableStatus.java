package com.raven.swing;

import com.raven.model.StatusType;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.JLabel;

public class TableStatus extends JLabel {

    private StatusType type;

    public TableStatus() {
        setOpaque(true);
        setForeground(Color.WHITE);
        setHorizontalAlignment(JLabel.CENTER);
        setFont(new Font("Segoe UI", Font.BOLD, 12));
    }

    public StatusType getType() {
        return type;
    }

    public void setType(StatusType type) {
        this.type = type;
        setText(type.toString());
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        if (type != null) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            GradientPaint gradient;

            // Asigna colores por tipo
            if (type == StatusType.PENDIENTE) {
                gradient = new GradientPaint(0, 0, new Color(186, 123, 247), 0, getHeight(), new Color(167, 94, 236));
            } else if (type == StatusType.CONFIRMADO) {
                gradient = new GradientPaint(0, 0, new Color(109, 247, 96), 0, getHeight(), new Color(62, 230, 98));
            } else if (type == StatusType.MODIFICADO) {
                gradient = new GradientPaint(0, 0, new Color(142, 142, 250), 0, getHeight(), new Color(123, 123, 245));
            } else if (type == StatusType.ACTIVO) {
                gradient = new GradientPaint(0, 0, new Color(0, 191, 165), 0, getHeight(), new Color(0, 168, 140));
            } else if (type == StatusType.INACTIVO) {
                gradient = new GradientPaint(0, 0, new Color(240, 98, 146), 0, getHeight(), new Color(230, 80, 120));
            } else {
                gradient = new GradientPaint(0, 0, new Color(211, 184, 61), 0, getHeight(), new Color(180, 150, 30));
            }

            g2.setPaint(gradient);
            g2.fillRoundRect(2, 2, getWidth() - 4, getHeight() - 4, 10, 10);

            g2.dispose();
        }

        super.paintComponent(g);
    }
}

package com.raven.swing;

import com.raven.model.StatusType;
import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

public class Table extends JTable {

    private boolean useStatusRendering = false;

    // Constructor para el diseñador (NetBeans)
    public Table() {
        this(false);
    }

    // Constructor principal: usaStatusRendering activa el renderizado especial
    public Table(boolean useStatusRendering) {
        this.useStatusRendering = useStatusRendering;

        setShowHorizontalLines(true);
        setGridColor(new Color(230, 230, 230));
        setRowHeight(45);
        getTableHeader().setReorderingAllowed(false);

        // Renderizador del encabezado
        getTableHeader().setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                TableHeader header = new TableHeader(value.toString());
                header.setHorizontalAlignment(JLabel.CENTER);
                return header;
            }
        });

        // Renderizador de celdas
        setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            private final TableStatus statusComponent = new TableStatus();

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                // Aplicar TableStatus solo si:
                // - useStatusRendering está activado
                // - La columna es la 5 (ajusta si es otra)
                // - El valor es de tipo StatusType
                if (useStatusRendering && column == 5 && value instanceof StatusType) {
                    statusComponent.setType((StatusType) value);
                    return statusComponent;
                }

                // Para todas las demás celdas, usa el estilo predeterminado
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(Color.WHITE);
                if (isSelected) {
                    c.setForeground(new Color(15, 89, 140));
                } else {
                    c.setForeground(new Color(102, 102, 102));
                }
                ((JLabel) c).setHorizontalAlignment(JLabel.CENTER);
                return c;
            }
        });
    }

    // Método para agregar filas
    public void addRow(Object[] row) {
        DefaultTableModel model = (DefaultTableModel) getModel();
        model.addRow(row);
    }

    // Método para limpiar la tabla
    public void clear() {
        DefaultTableModel model = (DefaultTableModel) getModel();
        model.setRowCount(0);
    }
}
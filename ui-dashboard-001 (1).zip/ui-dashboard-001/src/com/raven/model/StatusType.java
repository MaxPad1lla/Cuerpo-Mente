package com.raven.model;

public enum StatusType {
    PENDIENTE, CONFIRMADO, MODIFICADO, CANCELADO,  ACTIVO, INACTIVO
}
